from connection import create_connection, close_connection, send_command, host, port

connect = create_connection(host, port)

